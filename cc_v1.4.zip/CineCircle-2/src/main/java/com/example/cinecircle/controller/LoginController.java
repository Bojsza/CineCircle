package com.example.cinecircle.controller;

import com.example.cinecircle.domain.User;
import com.example.cinecircle.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    public LoginController(UserService userService,
                           PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    // GET: a bejelentkező űrlap
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";  // → templates/login.html
    }

    // POST: bejelentkezés feldolgozása
    @PostMapping("/login")
    public String processLogin(
            @RequestParam String usernameOrEmail,
            @RequestParam String password,
            Model model,
            HttpSession session
    ) {
        User user = userService.findByUsername(usernameOrEmail)
                .orElseGet(() ->
                    userService.findByEmail(usernameOrEmail).orElse(null)
                );

        if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
            model.addAttribute("error", "Helytelen felhasználónév vagy jelszó.");
            return "login";
        }

        // sikeres bejelentkezés: elmentjük a session-be
        session.setAttribute("loggedInUser", user);
        return "redirect:/profile";
    }
}

