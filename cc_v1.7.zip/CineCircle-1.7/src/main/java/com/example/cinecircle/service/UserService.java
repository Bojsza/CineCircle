package com.example.cinecircle.service;

import com.example.cinecircle.domain.User;
import com.example.cinecircle.domain.WatchStatus;
import com.example.cinecircle.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepo,
                       PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }

    
    public User register(String username, String email, String password) {
        // 1) Email-ellenőrzés
        userRepo.findByEmail(email)
                .ifPresent(u -> {
                    throw new IllegalArgumentException("Ez az email cím már foglalt");
                });

        // 2) Felhasználónév-ellenőrzés
        userRepo.findByUsername(username)
                .ifPresent(u -> {
                    throw new IllegalArgumentException("Ez a felhasználónév már foglalt");
                });

        // 3) Ha mindkettő szabad, jöhet a mentés
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setEmail(email);
        newUser.setPassword(passwordEncoder.encode(password));
        return userRepo.save(newUser);
    }

    

    public Optional<User> findByUsername(String username) {
        return userRepo.findByUsername(username);
    }

    public Optional<User> findByEmail(String email) {
        return userRepo.findById(email);
    }

    // --- Kedvencek / Favorites ---

    /**
     * Visszaadja a kedvenc filmek TMDb-ID-jait int-ként
     */
    public Set<Integer> listFavoriteIds(UUID userId) {
        return userRepo.findById(userId)
                .map(u -> u.getFavorites().stream()
                           .map(Long::intValue)
                           .collect(Collectors.toSet()))
                .orElse(Collections.emptySet());
    }

    public void addFavorite(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getFavorites().add(tmdbId);
        userRepo.save(u);
    }

    public void removeFavorite(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getFavorites().remove(tmdbId);
        userRepo.save(u);
    }

    // --- Watchlist ---

    /**
     * Visszaadja a watchlistet: TMDb-ID → TO_WATCH / WATCHED
     */
    public Map<Integer, WatchStatus> getWatchlistMap(UUID userId) {
        return userRepo.findById(userId)
                .map(u -> u.getWatchlist().entrySet().stream()
                           .collect(Collectors.toMap(
                               e -> e.getKey().intValue(),
                               Map.Entry::getValue
                           )))
                .orElse(Collections.emptyMap());
    }

    public void addToWatchlist(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().put(tmdbId, WatchStatus.TO_WATCH);
        userRepo.save(u);
    }

    public void markWatched(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().put(tmdbId, WatchStatus.WATCHED);
        userRepo.save(u);
    }

    public void removeFromWatchlist(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().remove(tmdbId);
        userRepo.save(u);
    }
}

