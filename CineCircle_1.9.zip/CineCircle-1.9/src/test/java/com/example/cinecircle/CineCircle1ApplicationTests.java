package com.example.cinecircle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CineCircle1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
