package com.example.cinecircle.repository;

import com.example.cinecircle.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByUsername(String username);
    // (ha szükséges) Optional<User> findByEmail(String email);
    Optional<User> findByEmail(String email); // ezzel visszaállt a register működése----
    
    @Query("SELECT u FROM User u WHERE u.id NOT IN :excludedIds")
    List<User> findAllExceptIds(@Param("excludedIds") List<UUID> excludedIds);
    
}
