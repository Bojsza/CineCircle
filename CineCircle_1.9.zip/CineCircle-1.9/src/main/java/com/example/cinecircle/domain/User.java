package com.example.cinecircle.domain;

import jakarta.persistence.*;
import java.util.*;

/**
 * Represents an application user with account details, favorites, watchlist, and social features.
 */
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String role = "USER"; // Default role

    /**
     * Favorite movies or shows stored by their TMDb IDs.
     */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
        name = "user_favorites",
        joinColumns = @JoinColumn(name = "user_id")
    )
    @Column(name = "tmdb_id")
    private Set<Long> favorites = new HashSet<>();

    /**
     * Watchlist mapping TMDb IDs to watch status (TO_WATCH or WATCHED).
     */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
        name = "user_watchlist",
        joinColumns = @JoinColumn(name = "user_id")
    )
    @MapKeyColumn(name = "tmdb_id")
    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private Map<Long, WatchStatus> watchlist = new HashMap<>();

    /**
     * Friend requests received by this user (UUIDs of senders).
     */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
        name = "friend_requests",
        joinColumns = @JoinColumn(name = "recipient_id")
    )
    @Column(name = "sender_id")
    private Set<UUID> incomingFriendRequests = new HashSet<>();

    /**
     * Accepted friends (UUIDs of friends).
     */
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
        name = "user_friends",
        joinColumns = @JoinColumn(name = "user_id")
    )
    @Column(name = "friend_id")
    private Set<UUID> friends = new HashSet<>();

    // --- Constructors ---

    public User() {}

    public User(String username, String email, String password, String role) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    // --- Getters and Setters ---

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Set<Long> getFavorites() {
        return favorites;
    }

    public void setFavorites(Set<Long> favorites) {
        this.favorites = favorites;
    }

    public Map<Long, WatchStatus> getWatchlist() {
        return watchlist;
    }

    public void setWatchlist(Map<Long, WatchStatus> watchlist) {
        this.watchlist = watchlist;
    }

    public Set<UUID> getIncomingFriendRequests() {
        return incomingFriendRequests;
    }

    public void setIncomingFriendRequests(Set<UUID> incomingFriendRequests) {
        this.incomingFriendRequests = incomingFriendRequests;
    }

    public Set<UUID> getFriends() {
        return friends;
    }

    public void setFriends(Set<UUID> friends) {
        this.friends = friends;
    }

    // --- Utility Methods ---

    public void addFavorite(Long tmdbId) {
        favorites.add(tmdbId);
    }

    public void removeFavorite(Long tmdbId) {
        favorites.remove(tmdbId);
    }

    public void addToWatchlist(Long tmdbId, WatchStatus status) {
        watchlist.put(tmdbId, status);
    }

    public void removeFromWatchlist(Long tmdbId) {
        watchlist.remove(tmdbId);
    }

    public void addFriend(UUID userId) {
        friends.add(userId);
    }

    public void removeFriend(UUID userId) {
        friends.remove(userId);
    }

    public void addIncomingFriendRequest(UUID senderId) {
        incomingFriendRequests.add(senderId);
    }

    public void removeIncomingFriendRequest(UUID senderId) {
        incomingFriendRequests.remove(senderId);
    }
}
