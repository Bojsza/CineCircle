package com.example.cinecircle.controller;

import com.example.cinecircle.domain.Movie;
import com.example.cinecircle.domain.User;
import com.example.cinecircle.domain.WatchStatus;
import com.example.cinecircle.service.TmdbService;
import com.example.cinecircle.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Controller
public class ProfileController {

    private static final Logger logger = LoggerFactory.getLogger(ProfileController.class);
    
    private final UserService userService;
    private final TmdbService tmdbService;

    public ProfileController(UserService userService,
                           TmdbService tmdbService) {
        this.userService = userService;
        this.tmdbService = tmdbService;
    }

    @GetMapping("/profile")
    public String showProfile(HttpSession session, Model model) {
        try {
            // 1. Session validation
            User sessionUser = (User) session.getAttribute("loggedInUser");
            if (sessionUser == null) {
                logger.warn("Unauthorized access attempt to /profile");
                return "redirect:/login";
            }

            // 2. Load fresh user data from database
            User user = userService.findByUsername(sessionUser.getUsername())
                    .orElseThrow(() -> {
                        logger.error("User not found in database: {}", sessionUser.getUsername());
                        return new RuntimeException("User not found");
                    });

            // 3. Load favorites with null checks
            List<Movie> favorites = loadFavorites(user.getId());
            
            // 4. Load watchlist items
            List<Movie> watchlist = loadWatchlist(user.getId());

            // 5. Add attributes to model
            model.addAttribute("user", user);
            model.addAttribute("favorites", favorites);
            model.addAttribute("watchlist", watchlist);

            logger.info("Profile loaded successfully for user: {}", user.getUsername());
            return "profile";

        } catch (Exception e) {
            logger.error("Error loading profile page", e);
            model.addAttribute("error", "Failed to load profile data");
            return "error"; // Make sure you have an error.html template
        }
    }

    @GetMapping("/profile/watchlist")
    public String showWatchlist(HttpSession session, 
                              Model model,
                              @RequestParam(required = false) List<UUID> friendIds) {
        User me = (User) session.getAttribute("loggedInUser");
        if (me == null) {
            return "redirect:/login";
        }

        // Load current user's friends
        List<User> friends = userService.getFriends(me.getId());
        model.addAttribute("friends", friends);

        // Store selected friend IDs
        List<UUID> selectedFriendIds = friendIds != null ? friendIds : Collections.emptyList();
        model.addAttribute("selectedFriendIds", selectedFriendIds);

        // Get common movies if friends are selected
        List<Integer> commonMovies = null;
        if (!selectedFriendIds.isEmpty()) {
            commonMovies = userService.findCommonWatchlistMovies(me.getId(), selectedFriendIds);
            model.addAttribute("commonMovies", commonMovies);
        }

        // Load watchlist - either filtered or full
        List<Movie> watchlist;
        if (commonMovies != null && !commonMovies.isEmpty()) {
            watchlist = commonMovies.stream()
                    .map(tmdbService::getMovieDetails)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        } else {
            watchlist = userService.getWatchlistMap(me.getId()).entrySet().stream()
                    .filter(e -> e.getValue() == WatchStatus.TO_WATCH)
                    .map(e -> tmdbService.getMovieDetails(e.getKey()))
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        }

        model.addAttribute("watchlist", watchlist);
        return "watchlist";
    }

    @GetMapping("/profile/friends")
    public String showFriends(HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login";
        }
        return "redirect:/friends?userId=" + user.getId();
    }

    // Helper methods
    private List<Movie> loadFavorites(UUID userId) {
        try {
            Set<Integer> favoriteIds = userService.listFavoriteIds(userId);
            if (favoriteIds == null) {
                return Collections.emptyList();
            }
            
            return favoriteIds.stream()
                    .map(tmdbService::getMovieDetails)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
                    
        } catch (Exception e) {
            logger.error("Error loading favorites for user: {}", userId, e);
            return Collections.emptyList();
        }
    }

    private List<Movie> loadWatchlist(UUID userId) {
        try {
            return userService.getWatchlistMap(userId).entrySet().stream()
                    .filter(e -> e.getValue() == WatchStatus.TO_WATCH)
                    .map(e -> tmdbService.getMovieDetails(e.getKey()))
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            logger.error("Error loading watchlist for user: {}", userId, e);
            return Collections.emptyList();
        }
    }
}