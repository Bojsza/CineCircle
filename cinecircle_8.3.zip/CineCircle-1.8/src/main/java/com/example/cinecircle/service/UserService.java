package com.example.cinecircle.service;

import com.example.cinecircle.domain.Rating;
import com.example.cinecircle.domain.User;
import com.example.cinecircle.domain.WatchStatus;
import com.example.cinecircle.repository.RatingRepository;
import com.example.cinecircle.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;
    private final RatingRepository ratingRepository;
    
    public UserService(UserRepository userRepo,
                       PasswordEncoder passwordEncoder,  RatingRepository ratingRepository) {
    		
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
        this.ratingRepository = ratingRepository;
    }

    // --- User Registration ---
    public User register(String username, String email, String password) {
        // 1) Email-ellenőrzés
        userRepo.findByEmail(email)
                .ifPresent(u -> {
                    throw new IllegalArgumentException("Ez az email cím már foglalt");
                });

        // 2) Felhasználónév-ellenőrzés
        userRepo.findByUsername(username)
                .ifPresent(u -> {
                    throw new IllegalArgumentException("Ez a felhasználónév már foglalt");
                });

        // 3) Ha mindkettő szabad, jöhet a mentés
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setEmail(email);
        newUser.setPassword(passwordEncoder.encode(password));
        return userRepo.save(newUser);
    }

    // --- User Search ---
    public Optional<User> findByUsername(String username) {
        return userRepo.findByUsername(username);
    }

    public Optional<User> findByEmail(String email) {
        return userRepo.findByEmail(email);
    }

    // --- Kedvencek / Favorites ---
    public Set<Integer> listFavoriteIds(UUID userId) {
        return userRepo.findById(userId)
                .map(u -> u.getFavorites().stream()
                           .map(Long::intValue)
                           .collect(Collectors.toSet()))
                .orElse(Collections.emptySet());
    }

    public void addFavorite(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getFavorites().add(tmdbId);
        userRepo.save(u);
    }

    public void removeFavorite(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getFavorites().remove(tmdbId);
        userRepo.save(u);
    }

    // --- Watchlist ---
    public Map<Integer, WatchStatus> getWatchlistMap(UUID userId) {
        return userRepo.findById(userId)
                .map(u -> u.getWatchlist().entrySet().stream()
                           .collect(Collectors.toMap(
                               e -> e.getKey().intValue(),
                               Map.Entry::getValue
                           )))
                .orElse(Collections.emptyMap());
    }

    public void addToWatchlist(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().put(tmdbId, WatchStatus.TO_WATCH);
        userRepo.save(u);
    }

    public void markWatched(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().put(tmdbId, WatchStatus.WATCHED);
        userRepo.save(u);
    }

    public void removeFromWatchlist(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().remove(tmdbId);
        userRepo.save(u);
    }
    
    public List<Integer> findCommonWatchlistMovies(UUID userId, List<UUID> friendIds) {
        // Get user's watchlist
        Set<Integer> userWatchlist = getWatchlistMap(userId).keySet();
        
        // Get intersection with all friends' watchlists
        return friendIds.stream()
                .map(this::getWatchlistMap)
                .map(Map::keySet)
                .reduce(userWatchlist, (common, friendWatchlist) -> {
                    common.retainAll(friendWatchlist);
                    return common;
                })
                .stream()
                .collect(Collectors.toList());
    }

    // --- Friend Requests ---

    /**
     * Sends a friend request from one user to another.
     */
    public boolean sendFriendRequest(UUID senderId, UUID recipientId) {
        if (senderId.equals(recipientId)) {
            return false; // Can't friend yourself
        }
        
        User recipient = userRepo.findById(recipientId)
                .orElseThrow(() -> new NoSuchElementException("Recipient not found"));
        
        // Check if request already exists
        if (recipient.getIncomingFriendRequests().contains(senderId)) {
            return false;
        }
        
        recipient.getIncomingFriendRequests().add(senderId);
        userRepo.save(recipient);
        return true;
    }

    /**
     * Accepts a friend request and adds both users to each other's friends list.
     */
    public void acceptFriendRequest(UUID userId, UUID requesterId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        User requester = userRepo.findById(requesterId)
                .orElseThrow(() -> new NoSuchElementException("Requester not found"));

        // Remove the incoming request
        user.getIncomingFriendRequests().remove(requesterId);

        // Add both users to each other's friends list
        user.getFriends().add(requesterId);
        requester.getFriends().add(userId);

        userRepo.save(user);
        userRepo.save(requester);
    }

    /**
     * Declines a friend request, removing it from the recipient's incoming requests.
     */
    public void declineFriendRequest(UUID userId, UUID requesterId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        user.getIncomingFriendRequests().remove(requesterId);
        userRepo.save(user);
    }
    
    public List<User> findAllExcept(UUID userId) {
        List<User> allUsers = userRepo.findAll();  // Get all users from the repository
        return allUsers.stream()
                       .filter(user -> !user.getId().equals(userId))  // Filter out the user with the given userId
                       .collect(Collectors.toList());
    }
    
 // Get current friends
    public List<User> getFriends(UUID userId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        
        return user.getFriends().stream()
                .map(friendId -> userRepo.findById(friendId).orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    // Get potential friends (non-friends)
    public List<User> getPotentialFriends(UUID userId) {
        User currentUser = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        
        Set<UUID> excludedIds = new HashSet<>();
        excludedIds.addAll(currentUser.getFriends());
        excludedIds.addAll(currentUser.getIncomingFriendRequests());
        excludedIds.add(userId); // exclude self
        
        return userRepo.findAll().stream()
                .filter(user -> !excludedIds.contains(user.getId()))
                .collect(Collectors.toList());
    }
    
    public void removeFriend(UUID userId, UUID friendId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        User friend = userRepo.findById(friendId)
                .orElseThrow(() -> new NoSuchElementException("Friend not found"));
        
        // Remove from both users' friend lists
        user.getFriends().remove(friendId);
        friend.getFriends().remove(userId);
        
        userRepo.save(user);
        userRepo.save(friend);
    }
    
    public boolean hasPendingRequest(UUID senderId, UUID recipientId) {
        User recipient = userRepo.findById(recipientId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        return recipient.getIncomingFriendRequests().contains(senderId);
    }
    //Metódus értékelés mentéséhez:
    public void saveOrUpdateRating(User user, int tmdbMovieId, int score) {
        Rating rating = ratingRepository
                .findByUserAndTmdbMovieId(user, tmdbMovieId)
                .orElse(new Rating(user, tmdbMovieId, score));

        rating.setScore(score);
        ratingRepository.save(rating);
    }
    //Metódus értékelés lekérdezéséhez:
    public Integer getUserRatingForMovie(User user, int tmdbMovieId) {
        return ratingRepository
                .findByUserAndTmdbMovieId(user, tmdbMovieId)
                .map(Rating::getScore)
                .orElse(null);
    }


}
