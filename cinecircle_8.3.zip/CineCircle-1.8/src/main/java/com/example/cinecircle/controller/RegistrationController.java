package com.example.cinecircle.controller;

import com.example.cinecircle.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RegistrationController {

    private final UserService userService;

    public RegistrationController(UserService userService) {
        this.userService = userService;
    }

    // GET: regisztrációs űrlap megjelenítése
    @GetMapping("/register")
    public String showForm() {
        return "register";  // templates/register.html
    }

    // POST: űrlap feldolgozása
    @PostMapping("/register")
    public String processRegistration(
            @RequestParam String username,
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam String confirmPassword,
            Model model
    ) {
        // egyszerű validáció
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "A két jelszó nem egyezik.");
            return "register";
        }

        try {
            userService.register(username, email, password);
            return "redirect:/login"; // majd ide jön a bejelentkező oldal
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "register";
        }
    }
}
