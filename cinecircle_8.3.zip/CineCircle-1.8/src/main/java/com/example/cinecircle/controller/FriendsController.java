package com.example.cinecircle.controller;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.cinecircle.domain.User;
import com.example.cinecircle.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class FriendsController {

    private final UserService userService;

    public FriendsController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/friends")
    public String showFriendsPage(HttpSession session, Model model) {
        User me = (User) session.getAttribute("loggedInUser");
        if (me == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("currentFriends", userService.getFriends(me.getId()));
        
        List<User> potentialFriends = userService.getPotentialFriends(me.getId());
        Map<UUID, Boolean> pendingStatusMap = potentialFriends.stream()
            .collect(Collectors.toMap(
                User::getId,
                user -> userService.hasPendingRequest(me.getId(), user.getId())
            ));
        
        model.addAttribute("potentialFriends", potentialFriends);
        model.addAttribute("pendingStatusMap", pendingStatusMap);
        model.addAttribute("currentUserId", me.getId());
        
        return "friends";
    }
    
    @PostMapping("/friends/remove/{id}")
    public String removeFriend(@PathVariable UUID id, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        if (me == null) {
            return "redirect:/login";
        }
        
        userService.removeFriend(me.getId(), id);
        return "redirect:/friends";
    }

    @PostMapping("/friends/request/{id}")
    public String sendRequest(@PathVariable UUID id, 
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        User me = (User) session.getAttribute("loggedInUser");
        if (me == null) {
            return "redirect:/login";
        }
        
        boolean success = userService.sendFriendRequest(me.getId(), id);
        if (!success) {
            redirectAttributes.addFlashAttribute("error", "Friend request already sent");
        }
        
        return "redirect:/friends";
    }

    @PostMapping("/friends/accept/{id}")
    public String acceptRequest(@PathVariable UUID id, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.acceptFriendRequest(me.getId(), id);
        return "redirect:/profile";
    }

    @PostMapping("/friends/decline/{id}")
    public String declineRequest(@PathVariable UUID id, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.declineFriendRequest(me.getId(), id);
        return "redirect:/profile";
    }
}
