package com.example.cinecircle.repository;

import com.example.cinecircle.domain.Rating;
import com.example.cinecircle.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RatingRepository extends JpaRepository<Rating, Long> {

    Optional<Rating> findByUserAndTmdbMovieId(User user, int tmdbMovieId);

    boolean existsByUserAndTmdbMovieId(User user, int tmdbMovieId);
}
