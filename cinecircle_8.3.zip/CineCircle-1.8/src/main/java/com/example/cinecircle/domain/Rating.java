

package com.example.cinecircle.domain;

import jakarta.persistence.*;

@Entity
@Table(name = "ratings", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "tmdbMovieId"}))
public class Rating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private User user;

    private int tmdbMovieId; // TMDb API ID

    private int score; // 1–10

    // Konstruktorok
    public Rating() {}

    public Rating(User user, int tmdbMovieId, int score) {
        this.user = user;
        this.tmdbMovieId = tmdbMovieId;
        this.score = score;
    }

    // Getters és Setters
    public Long getId() {
        return id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getTmdbMovieId() {
        return tmdbMovieId;
    }

    public void setTmdbMovieId(int tmdbMovieId) {
        this.tmdbMovieId = tmdbMovieId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
