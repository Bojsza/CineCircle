package com.example.cinecircle.service;

import com.example.cinecircle.domain.Rating;
import com.example.cinecircle.domain.User;
import com.example.cinecircle.repository.RatingRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RatingService {

    private final RatingRepository ratingRepository;

    public RatingService(RatingRepository ratingRepository) {
        this.ratingRepository = ratingRepository;
    }

    public Optional<Rating> getRating(User user, int tmdbMovieId) {
        return ratingRepository.findByUserAndTmdbMovieId(user, tmdbMovieId);
    }

    public void saveOrUpdateRating(User user, int tmdbMovieId, int score) {
        Optional<Rating> existingRating = ratingRepository.findByUserAndTmdbMovieId(user, tmdbMovieId);
        if (existingRating.isPresent()) {
            Rating rating = existingRating.get();
            rating.setScore(score);
            ratingRepository.save(rating);
        } else {
            Rating newRating = new Rating(user, tmdbMovieId, score);
            ratingRepository.save(newRating);
        }
    }
}
