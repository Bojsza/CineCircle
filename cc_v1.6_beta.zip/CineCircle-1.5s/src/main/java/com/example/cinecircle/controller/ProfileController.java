

package com.example.cinecircle.controller;

import com.example.cinecircle.domain.Movie;
import com.example.cinecircle.domain.User;
import com.example.cinecircle.domain.WatchStatus;
import com.example.cinecircle.service.TmdbService;
import com.example.cinecircle.service.UserService;
import jakarta.servlet.http.HttpSession;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import java.util.List;



@Controller
public class ProfileController {

    private final UserService userService;
    private final TmdbService tmdbService;

    public ProfileController(UserService userService,
                             TmdbService tmdbService) {
        this.userService = userService;
        this.tmdbService = tmdbService;
    }

    @GetMapping("/profile")
    public String showProfile(HttpSession session, Model model) {
        User me = (User) session.getAttribute("loggedInUser");
        if (me == null) {
            return "redirect:/login";
        }
        
        // hozzuk be a teljes User objektumot is, ha szükséges a nézet számára
        model.addAttribute("user", me);

       
        // Kedvencek listája Movie-objektumokkal
        List<Movie> favMovies = userService.listFavoriteIds(me.getId()).stream()
            .map(tmdbService::getMovieDetails)
            .collect(Collectors.toList());
        model.addAttribute("favorites", favMovies);

        // Watchlist listája Mapként, de itt csak a „TO_WATCH” státuszúakat mutatjuk
        List<Movie> toWatch = userService.getWatchlistMap(me.getId()).entrySet().stream()
            .filter(e -> e.getValue() == WatchStatus.TO_WATCH)
            .map(e -> tmdbService.getMovieDetails(e.getKey()))
            .collect(Collectors.toList());
        model.addAttribute("watchlist", toWatch);
        
        return "profile";
    }
}
