package com.example.cinecircle.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.cinecircle.domain.User;
import com.example.cinecircle.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class FriendsController {

    private final UserService userService;

    public FriendsController(UserService userService) {
        this.userService = userService;
    }

 // List all users except the current user
    @GetMapping("/friends")
    public String showFriendsPage(Model model, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        if (me == null) {
            return "redirect:/login";
        }
        List<User> allUsersExceptCurrent = userService.findAllExcept(me.getId());
        model.addAttribute("users", allUsersExceptCurrent);
        return "friends";
    }

    @PostMapping("/friends/request/{id}")
    public String sendRequest(@PathVariable UUID id, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.sendFriendRequest(me.getId(), id);
        return "redirect:/friends";
    }

    @PostMapping("/friends/accept/{id}")
    public String acceptRequest(@PathVariable UUID id, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.acceptFriendRequest(me.getId(), id);
        return "redirect:/profile";
    }

    @PostMapping("/friends/decline/{id}")
    public String declineRequest(@PathVariable UUID id, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.declineFriendRequest(me.getId(), id);
        return "redirect:/profile";
    }
}
