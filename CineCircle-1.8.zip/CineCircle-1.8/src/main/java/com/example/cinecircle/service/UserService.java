package com.example.cinecircle.service;

import com.example.cinecircle.domain.User;
import com.example.cinecircle.domain.WatchStatus;
import com.example.cinecircle.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {

    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepo,
                       PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }

    // --- User Registration ---
    public User register(String username, String email, String password) {
        // 1) Email-ellenőrzés
        userRepo.findByEmail(email)
                .ifPresent(u -> {
                    throw new IllegalArgumentException("Ez az email cím már foglalt");
                });

        // 2) Felhasználónév-ellenőrzés
        userRepo.findByUsername(username)
                .ifPresent(u -> {
                    throw new IllegalArgumentException("Ez a felhasználónév már foglalt");
                });

        // 3) Ha mindkettő szabad, jöhet a mentés
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setEmail(email);
        newUser.setPassword(passwordEncoder.encode(password));
        return userRepo.save(newUser);
    }

    // --- User Search ---
    public Optional<User> findByUsername(String username) {
        return userRepo.findByUsername(username);
    }

    public Optional<User> findByEmail(String email) {
        return userRepo.findByEmail(email);
    }

    // --- Kedvencek / Favorites ---
    public Set<Integer> listFavoriteIds(UUID userId) {
        return userRepo.findById(userId)
                .map(u -> u.getFavorites().stream()
                           .map(Long::intValue)
                           .collect(Collectors.toSet()))
                .orElse(Collections.emptySet());
    }

    public void addFavorite(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getFavorites().add(tmdbId);
        userRepo.save(u);
    }

    public void removeFavorite(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getFavorites().remove(tmdbId);
        userRepo.save(u);
    }

    // --- Watchlist ---
    public Map<Integer, WatchStatus> getWatchlistMap(UUID userId) {
        return userRepo.findById(userId)
                .map(u -> u.getWatchlist().entrySet().stream()
                           .collect(Collectors.toMap(
                               e -> e.getKey().intValue(),
                               Map.Entry::getValue
                           )))
                .orElse(Collections.emptyMap());
    }

    public void addToWatchlist(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().put(tmdbId, WatchStatus.TO_WATCH);
        userRepo.save(u);
    }

    public void markWatched(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().put(tmdbId, WatchStatus.WATCHED);
        userRepo.save(u);
    }

    public void removeFromWatchlist(UUID userId, long tmdbId) {
        User u = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        u.getWatchlist().remove(tmdbId);
        userRepo.save(u);
    }

    // --- Friend Requests ---

    /**
     * Sends a friend request from one user to another.
     */
    public void sendFriendRequest(UUID senderId, UUID recipientId) {
        User recipient = userRepo.findById(recipientId)
                .orElseThrow(() -> new NoSuchElementException("Recipient not found"));
        recipient.getIncomingFriendRequests().add(senderId);
        userRepo.save(recipient);
    }

    /**
     * Accepts a friend request and adds both users to each other's friends list.
     */
    public void acceptFriendRequest(UUID userId, UUID requesterId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        User requester = userRepo.findById(requesterId)
                .orElseThrow(() -> new NoSuchElementException("Requester not found"));

        // Remove the incoming request
        user.getIncomingFriendRequests().remove(requesterId);

        // Add both users to each other's friends list
        user.getFriends().add(requesterId);
        requester.getFriends().add(userId);

        userRepo.save(user);
        userRepo.save(requester);
    }

    /**
     * Declines a friend request, removing it from the recipient's incoming requests.
     */
    public void declineFriendRequest(UUID userId, UUID requesterId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        user.getIncomingFriendRequests().remove(requesterId);
        userRepo.save(user);
    }
    
    public List<User> findAllExcept(UUID userId) {
        List<User> allUsers = userRepo.findAll();  // Get all users from the repository
        return allUsers.stream()
                       .filter(user -> !user.getId().equals(userId))  // Filter out the user with the given userId
                       .collect(Collectors.toList());
    }
}
