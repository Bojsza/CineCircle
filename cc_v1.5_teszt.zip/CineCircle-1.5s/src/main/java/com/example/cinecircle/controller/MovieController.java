package com.example.cinecircle.controller;

import com.example.cinecircle.domain.Movie;
import com.example.cinecircle.domain.User;
import com.example.cinecircle.domain.WatchStatus;
import com.example.cinecircle.service.TmdbService;
import com.example.cinecircle.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
public class MovieController {

    private final TmdbService tmdbService;
    private final UserService userService;

    public MovieController(TmdbService tmdbService,
                           UserService userService) {
        this.tmdbService = tmdbService;
        this.userService = userService;
    }

    // 1) Homepage: popular movies + user státuszok
    @GetMapping("/")
    public String showHomePage(Model model, HttpSession session) {
        List<Movie> movies = tmdbService.getPopularMovies();
        model.addAttribute("movies", movies);

        // Ha be vagy jelentkezve, töltsd be a kedvenceidet és watchlist-edet
        User me = (User) session.getAttribute("loggedInUser");
        if (me != null) {
            Set<Integer> favIds = userService.listFavoriteIds(me.getId());
            Map<Integer, WatchStatus> wlMap = userService.getWatchlistMap(me.getId());
            model.addAttribute("favoriteIds", favIds);
            model.addAttribute("watchlistMap", wlMap);
        }

        return "index";
    }

    // 2) Movie detail
    @GetMapping("/movie/{id}")
    public String showMovieDetail(@PathVariable int id,
                                  Model model,
                                  HttpSession session) {
        Movie movie = tmdbService.getMovieDetails(id);
        model.addAttribute("movie", movie);

        User me = (User) session.getAttribute("loggedInUser");
        if (me != null) {
            Set<Integer> favIds = userService.listFavoriteIds(me.getId());
            model.addAttribute("isFavorite", favIds.contains(id));

            Map<Integer, WatchStatus> wlMap = userService.getWatchlistMap(me.getId());
            model.addAttribute("watchStatus", wlMap.get(id)); // null, TO_WATCH or WATCHED
        }

        return "movieDetail";
    }

    // 3) Search (szintén átadva a státuszok)
    @GetMapping("/movies/search")
    public String searchMovies(@RequestParam String query,
                               Model model,
                               HttpSession session) {
        List<Movie> searchResults = tmdbService.searchMovies(query);
        model.addAttribute("movies", searchResults);
        model.addAttribute("query", query);

        User me = (User) session.getAttribute("loggedInUser");
        if (me != null) {
            model.addAttribute("favoriteIds", userService.listFavoriteIds(me.getId()));
            model.addAttribute("watchlistMap", userService.getWatchlistMap(me.getId()));
        }

        return "searchResults";
    }
    
    // … a MovieController osztályon belül …
    /*
    @GetMapping("/profile")
    public String profile(Model model, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        if (me == null) {
            // ha nincs bejelentkezve, irányítsuk a login oldalra
            return "redirect:/login";
        }
        // kedvenceid TMDb-ID-ként
        Set<Integer> favIds = userService.listFavoriteIds(me.getId());
        // watchlist: ID → státusz
        Map<Integer, WatchStatus> wlMap = userService.getWatchlistMap(me.getId());

        model.addAttribute("favorites", favIds);
        model.addAttribute("watchlist", wlMap);
        return "profile";
    }*/

    

    // 4) Favorite kezelése
    @PostMapping("/movies/{id}/favorite/add")
    public String addFavorite(@PathVariable int id,
                              HttpSession session,
                              RedirectAttributes ra) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.addFavorite(me.getId(), (long) id);
        ra.addFlashAttribute("msg", "Hozzáadva a kedvencekhez");
        return "redirect:/movie/" + id;
    }

    @PostMapping("/movies/{id}/favorite/remove")
    public String removeFavorite(@PathVariable int id,
                                 HttpSession session,
                                 RedirectAttributes ra) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.removeFavorite(me.getId(), (long) id);
        ra.addFlashAttribute("msg", "Eltávolítva a kedvencek közül");
        return "redirect:/movie/" + id;
    }

    // 5) Watchlist kezelése
    @PostMapping("/movies/{id}/watchlist/add")
    public String addToWatchlist(@PathVariable int id,
                                 HttpSession session,
                                 RedirectAttributes ra) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.addToWatchlist(me.getId(), (long) id);
        ra.addFlashAttribute("msg", "Hozzáadva a watchlisthez");
        return "redirect:/movie/" + id;
    }

    @PostMapping("/movies/{id}/watchlist/mark-watched")
    public String markWatched(@PathVariable int id,
                              HttpSession session,
                              RedirectAttributes ra) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.markWatched(me.getId(), (long) id);
        ra.addFlashAttribute("msg", "Megjelölve megtekintettként");
        return "redirect:/movie/" + id;
    }

    @PostMapping("/movies/{id}/watchlist/remove")
    public String removeFromWatchlist(@PathVariable int id,
                                      HttpSession session,
                                      RedirectAttributes ra) {
        User me = (User) session.getAttribute("loggedInUser");
        userService.removeFromWatchlist(me.getId(), (long) id);
        ra.addFlashAttribute("msg", "Eltávolítva a watchlistből");
        return "redirect:/movie/" + id;
    }

    // 6) Profil – kedvencek
    @GetMapping("/profile/favorites")
    public String showFavorites(Model model, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        Set<Integer> favIds = userService.listFavoriteIds(me.getId());
        List<Movie> favMovies = favIds.stream()
                .map(tmdbService::getMovieDetails)
                .collect(Collectors.toList());
        model.addAttribute("movies", favMovies);
        return "favorites";
    }

    // 7) Profil – watchlist
    @GetMapping("/profile/watchlist")
    public String showWatchlist(Model model, HttpSession session) {
        User me = (User) session.getAttribute("loggedInUser");
        Map<Integer, WatchStatus> wl = userService.getWatchlistMap(me.getId());
        List<Movie> toWatch = wl.entrySet().stream()
                .filter(e -> e.getValue() == WatchStatus.TO_WATCH)
                .map(e -> tmdbService.getMovieDetails(e.getKey()))
                .collect(Collectors.toList());
        model.addAttribute("movies", toWatch);
        return "watchlist";
    }
}
