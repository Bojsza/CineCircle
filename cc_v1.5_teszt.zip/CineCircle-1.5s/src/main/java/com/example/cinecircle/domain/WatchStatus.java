package com.example.cinecircle.domain;

public enum WatchStatus {
    TO_WATCH,
    WATCHED
}
