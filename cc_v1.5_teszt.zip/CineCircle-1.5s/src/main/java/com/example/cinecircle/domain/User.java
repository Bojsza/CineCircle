package com.example.cinecircle.domain;

import jakarta.persistence.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    private String role = "USER"; // Default role

    // Kedvencek gyűjtemény (TMDb ID-ként)
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
        name = "user_favorites",
        joinColumns = @JoinColumn(name = "user_id")
    )
    @Column(name = "tmdb_id")
    private Set<Long> favorites = new HashSet<>();

    // Watchlist: TMDb ID → WatchStatus (TO_WATCH, WATCHED)
    @ElementCollection(fetch = FetchType.LAZY)
    @CollectionTable(
        name = "user_watchlist",
        joinColumns = @JoinColumn(name = "user_id")
    )
    @MapKeyColumn(name = "tmdb_id")
    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private Map<Long, WatchStatus> watchlist = new HashMap<>();

    // --- Getters & Setters ---

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Set<Long> getFavorites() {
        return favorites;
    }

    public void setFavorites(Set<Long> favorites) {
        this.favorites = favorites;
    }

    public Map<Long, WatchStatus> getWatchlist() {
        return watchlist;
    }

    public void setWatchlist(Map<Long, WatchStatus> watchlist) {
        this.watchlist = watchlist;
    }
}
