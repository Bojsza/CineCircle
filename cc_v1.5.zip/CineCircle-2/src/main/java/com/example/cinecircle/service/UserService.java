package com.example.cinecircle.service;

import com.example.cinecircle.domain.User;
import com.example.cinecircle.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;

    // ✅ IDE JÖN A PasswordEncoder: itt injektálja be a Spring
    public UserService(UserRepository userRepo,
                       PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.passwordEncoder = passwordEncoder;
    }

    public User register(String username, String email, String rawPassword) {
        userRepo.findByUsername(username)
                .ifPresent(u -> { throw new IllegalArgumentException("Username already taken"); });
        userRepo.findByEmail(email)
                .ifPresent(u -> { throw new IllegalArgumentException("Email already in use"); });

        User user = new User();
        user.setId(UUID.randomUUID());
        user.setUsername(username);
        user.setEmail(email);
        // ❗️ A rawPassword helyett már a bcrypt-hash kerüljön a DB-be
        user.setPassword(passwordEncoder.encode(rawPassword));
        return userRepo.save(user);  
    }
    
	 // a repository metódusainak delegálása:
	public Optional<User> findByUsername(String username) {
		return userRepo.findByUsername(username);
	}
	
	public Optional<User> findByEmail(String email) {
	        return userRepo.findByEmail(email);
	}
}
