package com.example.cinecircle.domain;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}