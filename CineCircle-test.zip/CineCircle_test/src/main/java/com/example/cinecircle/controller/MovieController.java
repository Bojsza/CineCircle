package com.example.cinecircle.controller;

import com.example.cinecircle.domain.Movie;
import com.example.cinecircle.service.TmdbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class MovieController {

    private final TmdbService tmdbService;

    @Autowired
    public MovieController(TmdbService tmdbService) {
        this.tmdbService = tmdbService;
    }

    // Homepage: List popular movies
    @GetMapping("/")
    public String showHomePage(Model model) {
        List<Movie> movies = tmdbService.getPopularMovies();
        model.addAttribute("movies", movies);
        addUserAttributesToModel(model);
        return "index";
    }

    // Movie detail page
    @GetMapping("/movie/{id}")
    public String showMovieDetail(@PathVariable int id, Model model) {
        Movie movie = tmdbService.getMovieDetails(id);
        model.addAttribute("movie", movie);
        addUserAttributesToModel(model);
        return "movieDetail";
    }

    // Search movies
    @GetMapping("/movies/search")
    public String searchMovies(@RequestParam("query") String query, Model model) {
        List<Movie> searchResults = tmdbService.searchMovies(query);
        model.addAttribute("movies", searchResults);
        model.addAttribute("query", query);
        addUserAttributesToModel(model);
        return "searchResults";
    }

    // Rate a movie (protected endpoint)
    @PostMapping("/movie/{id}/rate")
    @PreAuthorize("hasRole('USER')")
    public String rateMovie(@PathVariable int id, @RequestParam int rating) {
        // Implement rating logic here
        return "redirect:/movie/" + id;
    }

    // Add to watchlist (protected endpoint)
    @PostMapping("/movie/{id}/watchlist")
    @PreAuthorize("hasRole('USER')")
    public String addToWatchlist(@PathVariable int id) {
        // Implement watchlist logic here
        return "redirect:/movie/" + id;
    }

    private void addUserAttributesToModel(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated() && !authentication.getName().equals("anonymousUser")) {
            model.addAttribute("currentUser", authentication.getName());
            model.addAttribute("isAuthenticated", true);
        } else {
            model.addAttribute("isAuthenticated", false);
        }
    }
}